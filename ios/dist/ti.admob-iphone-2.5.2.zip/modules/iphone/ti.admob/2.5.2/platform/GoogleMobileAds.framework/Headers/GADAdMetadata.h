//
//  GADAdMetadata.h
//  Google Mobile Ads SDK
//
//  Copyright 2017 Google LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

/// Ad metadata key type.
typedef NSString *GADAdMetadataKey NS_STRING_ENUM;
